import Lenis from './assets/vendor/lenis/lenis.mjs';
const reduced=matchMedia('(prefers-reduced-motion: reduce)');let lenis=null;
function init(){lenis?.destroy();lenis=null;if(reduced.matches){document.documentElement.dataset.scrollMode='native';return}lenis=new Lenis({autoRaf:true,duration:.85,easing:t=>1-Math.pow(1-t,4),smoothWheel:true,syncTouch:false,anchors:{offset:-80,duration:.85},prevent:node=>!!node.closest?.('dialog,[data-lenis-prevent]')});document.documentElement.dataset.scrollMode='smooth';syncDialog()}
function syncDialog(){if(!lenis)return;if(document.querySelector('dialog[open]'))lenis.stop();else{lenis.start();lenis.resize()}}
const observer=new MutationObserver(syncDialog);document.querySelectorAll('dialog').forEach(d=>observer.observe(d,{attributes:true,attributeFilter:['open']}));
reduced.addEventListener('change',init);document.addEventListener('visibilitychange',()=>{if(document.hidden)lenis?.stop();else syncDialog()});addEventListener('pageshow',()=>{lenis?.resize();syncDialog()});addEventListener('pagehide',e=>{if(e.persisted)lenis?.stop();else{lenis?.destroy();observer.disconnect()}});init();
const header=document.querySelector('.home-page .site-header');if(header)new ResizeObserver(()=>document.documentElement.style.setProperty('--site-header-height',`${header.offsetHeight}px`)).observe(header);

