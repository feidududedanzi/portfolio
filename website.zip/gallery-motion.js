/* Time-based inertia and low-amplitude photo motion share the site easing. */
(()=>{const reduced=matchMedia('(prefers-reduced-motion: reduce)');
document.querySelectorAll('.gallery').forEach(g=>{
 const cards=[...g.querySelectorAll('figure')];let raf=0,down=false,lastX=0,lastT=0,velocity=0,previous=g.scrollLeft,tilt=0,visible=true,frameTime=0;
 function reset(){cards.forEach(c=>{c.style.transform='';c.querySelector('img').style.transform=''});tilt=0;frameTime=0}
 function frame(now){raf=0;if(!visible||document.hidden)return;const dt=frameTime?Math.min((now-frameTime)/1000,.04):1/60;frameTime=now;
  if(!down&&Math.abs(velocity)>4&&!reduced.matches){const before=g.scrollLeft;g.scrollLeft+=velocity*dt;velocity*=Math.exp(-6*dt);if(g.scrollLeft===before)velocity=0}
  const delta=g.scrollLeft-previous;previous=g.scrollLeft;
  if(!reduced.matches){tilt+=(Math.max(-1.8,Math.min(1.8,-delta/dt*.002))-tilt)*(1-Math.exp(-10*dt));const r=g.getBoundingClientRect(),bounds=cards.map(c=>c.getBoundingClientRect());cards.forEach((c,i)=>{const b=bounds[i],progress=(b.left+b.width/2-r.left-r.width/2)/r.width;c.style.transform=`perspective(1200px) rotateY(${Math.max(-2,Math.min(2,progress*2))}deg) rotateZ(${tilt}deg)`;c.querySelector('img').style.transform=`scale(1.06) translateX(${Math.max(-6,Math.min(6,-progress*6))}px)`})}
  if(down||Math.abs(velocity)>4||Math.abs(tilt)>.015||Math.abs(delta)>.1)raf=requestAnimationFrame(frame);else frameTime=0;
 }
 function schedule(){if(!raf&&visible)raf=requestAnimationFrame(frame)}
 g.addEventListener('scroll',schedule,{passive:true});
 g.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse'||e.button!==0)return;down=true;velocity=0;lastX=e.clientX;lastT=performance.now();g.setPointerCapture(e.pointerId);g.classList.add('is-dragging');schedule()});
 g.addEventListener('pointermove',e=>{if(!down)return;const now=performance.now(),dx=lastX-e.clientX;g.scrollLeft+=dx;const speed=dx/Math.max(8,now-lastT)*1000;velocity=reduced.matches?0:velocity*.35+Math.max(-1300,Math.min(1300,speed))*.65;lastX=e.clientX;lastT=now;schedule()});
 function release(){if(!down)return;down=false;g.classList.remove('is-dragging');if(performance.now()-lastT>90)velocity=0;schedule()}
 g.addEventListener('pointerup',release);g.addEventListener('pointercancel',()=>{velocity=0;release()});g.addEventListener('lostpointercapture',release);g.addEventListener('dragstart',e=>e.preventDefault());
 g.addEventListener('keydown',e=>{if(['ArrowRight','ArrowLeft'].includes(e.key)){e.preventDefault();velocity=0;g.scrollBy({left:e.key==='ArrowRight'?300:-300,behavior:reduced.matches?'instant':'smooth'})}});
 new IntersectionObserver(e=>{visible=e[0].isIntersecting;if(visible){previous=g.scrollLeft;schedule()}else{cancelAnimationFrame(raf);raf=0;velocity=0;frameTime=0}},{threshold:0}).observe(g);
 reduced.addEventListener('change',()=>{velocity=0;reset();if(!reduced.matches)schedule()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;velocity=0;frameTime=0}else schedule()});
});})();
