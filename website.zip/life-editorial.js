/* A single stack-to-grid entrance; normal document scrolling afterwards. */
(()=>{const grid=document.querySelector('.life-editorial');if(!grid)return;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');if(reduced.matches)return;
 const cards=[...grid.children];let played=false,animations=[];
 const observer=new IntersectionObserver(entries=>{if(!entries.some(e=>e.isIntersecting)||played)return;played=true;observer.disconnect();
  const bounds=grid.getBoundingClientRect(),rects=cards.map(c=>c.getBoundingClientRect());const cx=bounds.left+bounds.width/2,cy=bounds.top+Math.min(250,innerHeight*.28);
  cards.forEach((card,i)=>{const r=rects[i],scale=Math.min(260/r.width,300/r.height,.7),x=cx-r.left-r.width/2,y=cy-r.top-r.height/2;
   const animation=card.animate([{transform:`translate(${x}px,${y}px) rotate(${(i-3.5)*3}deg) scale(${scale})`,opacity:i<4?1:.35},{transform:'translate(0,0) rotate(0deg) scale(1)',opacity:1}],{duration:1100,delay:i*45,easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'});animations.push(animation);
  });grid.dataset.entered='true';
 },{threshold:0,rootMargin:'0px 0px -18% 0px'});observer.observe(grid);
 function finish(){animations.forEach(a=>a.finish());animations=[]}
 reduced.addEventListener('change',e=>{if(e.matches){finish();observer.disconnect()}});addEventListener('resize',finish,{passive:true});
})();
