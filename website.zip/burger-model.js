import * as THREE from './assets/vendor/three/three.module.js';

// Original procedural food model, modeled for this portfolio. No reference-site assets.
export function createBurgerModel(host,options={}){
 const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power',preserveDrawingBuffer:!!options.capture});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;
 host.append(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(32,1,.1,50);camera.position.set(0,.25,8.4);camera.lookAt(0,0,0);scene.add(new THREE.HemisphereLight(0xfff4e1,0x4b3926,1.1));
 function light(color,intensity,x,y,z){const l=new THREE.DirectionalLight(color,intensity);l.position.set(x,y,z);scene.add(l)}
 light(0xfff3dd,2.3,-3,6,6);light(0xffffff,.7,4,1,5);light(0xffc477,1.4,1,3,-4);
 const model=new THREE.Group();scene.add(model);let seed=7859;const assets=[];
 function rand(){seed=seed*16807%2147483647;return(seed-1)/2147483646}
 function texture(kind){const w=512,h=256,c=document.createElement('canvas');c.width=w;c.height=h;const cx=c.getContext('2d'),d=cx.createImageData(w,h);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){let u=x/w,v=y/h,n=rand(),coarse=(Math.sin(u*35+Math.sin(v*24)*2)+Math.sin(u*71-v*46)+Math.sin(u*13+v*29))*.11,b;
   if(kind==='bun'){let toast=Math.pow(Math.max(0,Math.sin(v*Math.PI)),.5),grain=(n-.5)*34+coarse*37+(n>.965?-28:0);b=[174+toast*43+grain,86+toast*49+grain,25+toast*29+grain]}
   else if(kind==='beef'){let grain=(n-.5)*45+coarse*30,crust=n>.92?-42:0,grill=Math.pow(Math.max(0,Math.sin(u*78+v*5)),16)*-12;b=[95+grain+crust+grill,48+grain*.58+crust*.5+grill,24+grain*.3+crust*.2]}
   else {let grain=(n-.5)*18+coarse*20;b=[182+grain,28+grain*.35,15+grain*.25]}
   let i=(y*w+x)*4;for(let j=0;j<3;j++)d.data[i+j]=THREE.MathUtils.clamp(b[j],0,255);d.data[i+3]=255;
  }cx.putImageData(d,0,0);const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),4);assets.push(tex);return tex}
 const bunMap=texture('bun'),beefMap=texture('beef'),tomatoMap=texture('tomato');
 const bunMat=new THREE.MeshStandardMaterial({map:bunMap,bumpMap:bunMap,bumpScale:.025,roughness:.63,color:0xfbd7ab}),beefMat=new THREE.MeshStandardMaterial({map:beefMap,bumpMap:beefMap,bumpScale:.055,roughness:.82,color:0xd9c4ad}),tomatoMat=new THREE.MeshStandardMaterial({map:tomatoMap,bumpMap:tomatoMap,bumpScale:.015,roughness:.32}),onionMat=new THREE.MeshStandardMaterial({color:0xe8e5c8,roughness:.46}),seedMat=new THREE.MeshStandardMaterial({color:0xead8a6,roughness:.8});
 function lathe(profile,y,mat,phase=1,rough=.008){const geo=new THREE.LatheGeometry(profile.map(p=>new THREE.Vector2(...p)),96),pos=geo.attributes.position;
  for(let i=0;i<pos.count;i++){const x=pos.getX(i),yy=pos.getY(i),z=pos.getZ(i),a=Math.atan2(z,x),r=Math.hypot(x,z);if(r>.01){let d=1+Math.sin(a*7+phase)*rough+Math.sin(a*17+yy*20+phase)*rough*.7+Math.sin(a*39-yy*28+phase)*rough*.28;pos.setXYZ(i,x*d,yy+Math.sin(a*19+phase)*rough*.35,z*d)}}geo.computeVertexNormals();assets.push(geo);const mesh=new THREE.Mesh(geo,mat);mesh.position.y=y;model.add(mesh);return mesh}
 lathe([[0,0],[.7,0],[1,.035],[1.12,.12],[1.13,.22],[1.07,.31],[0,.32]],-1.66,bunMat,1,.009);
 for(let j=0;j<8;j++){const m=lathe([[0,0],[.8,0],[1.015,.015],[1.11,.05],[1.13,.1],[1.1,.17],[.98,.215],[.7,.23],[0,.22]],-1.3+j*.232,beefMat,3+j*3,.023);m.position.x=Math.sin(j*3.2)*.045;m.position.z=Math.cos(j*2.7)*.045;m.rotation.y=j*.63;m.rotation.z=Math.sin(j*1.3)*.019}
 function lettuce(y,phase,rotation=0){const N=120,R=13,vertices=[],colors=[],indices=[];
  for(let ring=0;ring<=R;ring++)for(let j=0;j<=N;j++){const a=j/N*Math.PI*2+rotation,r=ring/R,radius=r*(1.12+.08*Math.sin(a*7+phase)+.04*Math.sin(a*19+phase)),yy=y+Math.pow(r,3)*(.095*Math.sin(a*9+phase)+.045*Math.sin(a*23-phase))-.11*Math.pow(r,7);vertices.push(Math.cos(a)*radius,yy,Math.sin(a)*radius);const col=new THREE.Color().setHSL(.255+.025*Math.sin(a*8+phase),.78,.20+.08*r+.035*Math.sin(a*13+r*20));colors.push(col.r,col.g,col.b)}
  for(let r=0;r<R;r++)for(let j=0;j<N;j++){let a=r*(N+1)+j,b=a+N+1;indices.push(a,b,a+1,b,b+1,a+1)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();assets.push(g);const m=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.55,side:THREE.DoubleSide});assets.push(m);model.add(new THREE.Mesh(g,m))}
 lettuce(.59,1);lettuce(.64,5,.21);lathe([[0,0],[.96,0],[1.075,.025],[1.09,.08],[1.03,.145],[.9,.155],[0,.155]],.64,tomatoMat,8,.009);
 const onionGeo=new THREE.TorusGeometry(.82,.026,8,88);onionGeo.rotateX(Math.PI/2);assets.push(onionGeo);for(let i=0;i<3;i++){const m=new THREE.Mesh(onionGeo,onionMat);m.position.set((i-1)*.08,.835+i*.043,Math.sin(i*2)*.06);m.scale.setScalar(1-i*.11);model.add(m)}
 // Reuse a small region of the user's real burger as the cooked-meat surface.
 const sourcePhoto=new Image();sourcePhoto.onload=()=>{const c=document.createElement('canvas');c.width=512;c.height=256;const ctx=c.getContext('2d');ctx.drawImage(sourcePhoto,sourcePhoto.width*.26,sourcePhoto.height*.46,sourcePhoto.width*.48,sourcePhoto.height*.12,0,0,512,256);beefMap.image=c;beefMap.needsUpdate=true;host.dataset.texture='photo';host.dispatchEvent(new Event('burger-material-ready'))};sourcePhoto.src='/assets/more-works/burger-cutout.webp';
 const bunY=.95;lathe([[0,0],[.85,0],[1.085,.03],[1.15,.11],[1.14,.23],[1.09,.38],[.97,.54],[.79,.68],[.54,.79],[.23,.85],[0,.86]],bunY,bunMat,12,.006);
 const seedGeo=new THREE.SphereGeometry(1,8,6),seeds=new THREE.InstancedMesh(seedGeo,seedMat,175),dummy=new THREE.Object3D(),normal=new THREE.Vector3(),up=new THREE.Vector3(0,1,0);assets.push(seedGeo);
 for(let i=0;i<175;i++){const a=rand()*Math.PI*2,r=Math.sqrt(rand())*1.07,h=.11+.76*Math.sqrt(Math.max(0,1-(r/1.15)**2));normal.set(Math.cos(a)*r,.9*Math.sqrt(Math.max(.05,1-(r/1.15)**2)),Math.sin(a)*r).normalize();dummy.position.set(Math.cos(a)*r,bunY+h+.008,Math.sin(a)*r);dummy.quaternion.setFromUnitVectors(up,normal);dummy.rotateY(rand()*Math.PI);dummy.scale.set(.022,.012,.052*(.7+rand()*.5));dummy.updateMatrix();seeds.setMatrixAt(i,dummy.matrix)}model.add(seeds);
 function resize(){const w=host.clientWidth,h=host.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.position.z=w<600?9.5:8.4;camera.updateProjectionMatrix()}
 const sizeObserver=new ResizeObserver(resize);sizeObserver.observe(host);resize();
 function draw(s){model.position.x=s.x*(camera.aspect<.8?.5:1.8);model.position.y=-.12-s.y*.7+Math.sin(s.time*.7)*.035;model.rotation.set(s.y*.34+.13,s.yaw+s.x*.65,-.23+s.x*.2+(s.scroll-.5)*.35);renderer.render(scene,camera);host.dataset.yaw=model.rotation.y.toFixed(3);host.dataset.drawCalls=renderer.info.render.calls}
 return{draw,snapshot(){renderer.render(scene,camera);return renderer.domElement.toDataURL('image/png')},dispose(){sizeObserver.disconnect();renderer.dispose();assets.forEach(a=>a.dispose());[bunMat,beefMat,tomatoMat,onionMat,seedMat].forEach(m=>m.dispose());renderer.domElement.remove()}};
}
