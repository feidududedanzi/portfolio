import * as THREE from './assets/vendor/three/three.module.js';
const host=document.querySelector('.spatial-canvas'),stage=document.querySelector('.spatial-stage');
if(host&&stage){
 const reduce=matchMedia('(prefers-reduced-motion: reduce)');
 let renderer,raf=0,last=0,time=0,paused=false,visible=true,covered=false,drag=false,startX=0,startYaw=0,yaw=0,goalYaw=0,tilt=0,goalTilt=0,current=0;
 const resources=[];
 try{
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'low-power'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0x101119);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;host.append(renderer.domElement);
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(34,1,.1,80),world=new THREE.Group();scene.add(world);
 scene.add(new THREE.HemisphereLight(0xf1f3ff,0x24243a,3));
 for(const [color,intensity,x,y,z] of [[0xffffff,5,-5,7,8],[0x7a8cff,3,6,1,4]]){const l=new THREE.DirectionalLight(color,intensity);l.position.set(x,y,z);scene.add(l)}
 function shape(w,h,r){const s=new THREE.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s}
 function slab(w,h,d,r,color,z){const g=new THREE.ExtrudeGeometry(shape(w,h,r),{depth:d,bevelEnabled:true,bevelSize:.055,bevelThickness:.055,bevelSegments:4,steps:1,curveSegments:24});g.translate(0,0,-d/2);const m=new THREE.MeshStandardMaterial({color,metalness:color===0xc4c8d6?.72:.25,roughness:.24});const mesh=new THREE.Mesh(g,m);mesh.position.z=z;world.add(mesh);resources.push(g,m);return mesh}
 slab(6.35,8.1,.65,.24,0x253bed,-.24);
 slab(6.12,7.94,.37,.16,0xc4c8d6,.12);
 slab(6.28,8.08,.17,.22,0x252733,.42);
 // Fine inset page edges belong to one bound volume, never scattered pieces.
 const edgeMat=new THREE.MeshStandardMaterial({color:0x70778c,metalness:.5,roughness:.32});resources.push(edgeMat);
 for(let i=0;i<7;i++){const g=new THREE.BoxGeometry(.012,7.6,.012);const line=new THREE.Mesh(g,edgeMat);line.position.set(3.064,0,-.02+i*.045);world.add(line);resources.push(g)}
 const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=1560;const ctx=canvas.getContext('2d');const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=renderer.capabilities.getMaxAnisotropy();resources.push(texture);
 const faceGeo=new THREE.PlaneGeometry(5.94,7.72),faceMat=new THREE.MeshStandardMaterial({map:texture,roughness:.52,metalness:0});const face=new THREE.Mesh(faceGeo,faceMat);face.position.z=.575;world.add(face);resources.push(faceGeo,faceMat);
 const projects=[['01','MUSHROOM RENT','PRODUCT / UX / UI','/assets/projects/mushroom-rent/cover-document.webp'],['02','READING THE SILK ROAD','VISUAL / CAMPAIGN','/assets/projects/visual-design/cover-document.webp'],['03','DESIGN WITH PURPOSE','EXPERIENCE / VISUAL','/assets/projects/portfolio/cover-document.webp']];
 const images=projects.map(()=>null);
 function paint(){const p=projects[current];ctx.fillStyle='#e9eaf0';ctx.fillRect(0,0,1200,1560);ctx.fillStyle='#202432';ctx.font='500 23px Arial';ctx.fillText('CHEN LUYANG / SELECTED WORK',66,84);ctx.fillText('PORTFOLIO — '+p[0],66,1435);ctx.font='bold 104px Arial';ctx.fillText('DESIGN',60,224);ctx.fillText('WITH PURPOSE.',60,332);ctx.fillStyle='#283ee8';ctx.fillRect(66,382,1068,5);
 ctx.save();ctx.beginPath();ctx.rect(66,445,1068,746);ctx.clip();ctx.fillStyle='#d4d7e3';ctx.fillRect(66,445,1068,746);const img=images[current];if(img){const scale=Math.min(1068/img.width,746/img.height);ctx.drawImage(img,66+(1068-img.width*scale)/2,445+(746-img.height*scale)/2,img.width*scale,img.height*scale)}ctx.restore();
 ctx.fillStyle='#222633';ctx.font='bold 39px Arial';ctx.fillText(p[1],66,1280);ctx.font='24px Arial';ctx.fillStyle='#5c6273';ctx.fillText(p[2],66,1328);ctx.font='24px Arial';ctx.fillText('PRODUCT THINKING. VISUAL EXPRESSION.',66,1490);ctx.fillStyle='#283ee8';ctx.font='bold 64px Arial';ctx.fillText(p[0],1040,1460);texture.needsUpdate=true;host.dataset.project=p[0]}
 projects.forEach((p,i)=>{const img=new Image();img.onload=()=>{images[i]=img;paint();if(paused||reduce.matches)draw(0)};img.src=p[3]});paint();
 function next(){current=(current+1)%projects.length;paint();goalYaw=-.24;if(paused||reduce.matches)draw(0)}
 const turn=document.querySelector('#volume-next');turn?.addEventListener('click',next);
 function resize(){const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.position.set(0,0,w<600?22:18.6);camera.updateProjectionMatrix();world.scale.setScalar(w<600?.77:1);draw(0)}
 function draw(dt){const ease=Math.min(1,dt*5);yaw+=(goalYaw-yaw)*ease;tilt+=(goalTilt-tilt)*ease;world.rotation.set(.10+tilt,-.30+yaw,-.075);world.position.y=reduce.matches?0:Math.sin(time*.65)*.10;renderer.render(scene,camera);host.dataset.frame=String(Number(host.dataset.frame||0)+1);host.dataset.yaw=yaw.toFixed(3);host.dataset.objects='1'}
 function stop(){cancelAnimationFrame(raf);raf=0;last=0}
 function loop(now){raf=0;if(!visible||paused||covered||document.hidden||reduce.matches)return;const dt=last?Math.min((now-last)/1000,.06):.016;last=now;time+=dt;draw(dt);raf=requestAnimationFrame(loop)}
 function start(){if(!raf&&visible&&!paused&&!covered&&!document.hidden&&!reduce.matches)raf=requestAnimationFrame(loop)}
 stage.addEventListener('pointerdown',e=>{if(e.target.closest('button,a')||reduce.matches)return;drag=true;startX=e.clientX;startYaw=goalYaw;stage.setPointerCapture(e.pointerId)});
 stage.addEventListener('pointermove',e=>{if(reduce.matches)return;const r=stage.getBoundingClientRect();goalYaw=drag?THREE.MathUtils.clamp(startYaw+(e.clientX-startX)*.004,-.65,.65):(e.clientX-r.left-r.width/2)/r.width*.32;goalTilt=-(e.clientY-r.top-r.height/2)/r.height*.18},{passive:true});
 function release(){drag=false;goalYaw=0;goalTilt=0}stage.addEventListener('pointerup',release);stage.addEventListener('pointercancel',release);stage.addEventListener('pointerleave',()=>{if(!drag)release()});stage.addEventListener('lostpointercapture',release);
 stage.addEventListener('keydown',e=>{if(e.target!==stage)return;if(['ArrowLeft','ArrowRight','Enter',' '].includes(e.key)){e.preventDefault();if(e.key==='Enter'||e.key===' ')next();else goalYaw=THREE.MathUtils.clamp(goalYaw+(e.key==='ArrowLeft'?-.18:.18),-.65,.65)}if(e.key==='Escape')release();if(reduce.matches||paused)draw(0)});
 const motion=document.querySelector('#motion-toggle');motion.addEventListener('click',()=>{paused=!paused;motion.setAttribute('aria-pressed',String(paused));motion.dataset.paused=String(paused);if(paused)stop();else start()});
 const io=new IntersectionObserver(e=>{visible=e[0].isIntersecting;visible?start():stop()});io.observe(stage);
 const mo=new MutationObserver(()=>{covered=!!document.querySelector('dialog[open]');covered?stop():start()});document.querySelectorAll('dialog').forEach(d=>mo.observe(d,{attributes:true,attributeFilter:['open']}));
 document.addEventListener('visibilitychange',()=>document.hidden?stop():start());reduce.addEventListener('change',()=>{stop();release();yaw=tilt=0;draw(0);start()});
 const ro=new ResizeObserver(resize);ro.observe(host);resize();host.dataset.state='ready';start();
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();stop();host.dataset.state='fallback'});
 addEventListener('pagehide',e=>{stop();if(!e.persisted){ro.disconnect();io.disconnect();mo.disconnect();resources.forEach(r=>r.dispose());renderer.dispose()}});addEventListener('pageshow',start);
 }catch(error){renderer?.dispose();host.dataset.state='fallback';console.warn('Portfolio volume uses its static fallback.',error)}
}

const menu=document.querySelector('#portfolio-menu'),menuButton=document.querySelector('#menu-toggle');
menuButton.addEventListener('click',()=>{menu.showModal();menuButton.setAttribute('aria-expanded','true')});
let menuClosing=false;function closeMenu(){if(menuClosing||!menu.open)return;menuClosing=true;const finish=()=>{menu.close();menuClosing=false};if(matchMedia('(prefers-reduced-motion: reduce)').matches)finish();else menu.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(8px)'}],{duration:180,easing:'ease-in'}).finished.then(finish,finish)}menu.querySelector('.menu-close').addEventListener('click',closeMenu);menu.addEventListener('cancel',e=>{e.preventDefault();closeMenu()});menu.addEventListener('close',()=>{menuButton.setAttribute('aria-expanded','false');menuButton.focus()});menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>menu.close()));

