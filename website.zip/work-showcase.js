/* Manual project selection. No autoplay and no scroll interception. */
document.querySelectorAll('.work-showcase').forEach(root=>{
 const tabs=[...root.querySelectorAll('[role=tab]')],panels=[...root.querySelectorAll('[role=tabpanel]')];let current=0;
 function select(index,focus=false){current=(index+tabs.length)%tabs.length;tabs.forEach((tab,i)=>{const active=i===current;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;panels[i].classList.toggle('is-active',active);panels[i].inert=!active});root.querySelector('.work-index-count').textContent=`0${current+1} / 0${tabs.length}`;if(focus)tabs[current].focus()}
 tabs.forEach((tab,i)=>{tab.addEventListener('click',()=>select(i));tab.addEventListener('keydown',e=>{let target;if(['ArrowRight','ArrowDown'].includes(e.key))target=current+1;if(['ArrowLeft','ArrowUp'].includes(e.key))target=current-1;if(e.key==='Home')target=0;if(e.key==='End')target=tabs.length-1;if(target!==undefined){e.preventDefault();select(target,true)}})});
 root.querySelectorAll('[data-work-step]').forEach(button=>button.addEventListener('click',()=>select(current+Number(button.dataset.workStep))));
});
