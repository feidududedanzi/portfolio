/* Local pointer state, one RAF per event batch, scroll work only while visible. */
(()=>{
 const area=document.querySelector('.burger-playground');if(!area)return;
 const burger=area.querySelector('.burger-object'),reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let visible=false,raf=0,dragging=false,originX=0,originY=0,moved=false,returnTimer=0,popTimer=0,lastPoint=null;
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 function render(){raf=0;if(reduced.matches)return;
  if(visible){const r=area.getBoundingClientRect();area.style.setProperty('--burger-scroll',clamp((innerHeight-r.top)/(r.height+innerHeight),0,1).toFixed(4))}
  if(lastPoint){const {x,y}=lastPoint;area.style.setProperty('--burger-ry',`${x*16}deg`);area.style.setProperty('--burger-rx',`${-y*12}deg`);lastPoint=null}
 }
 function schedule(){if(!raf)raf=requestAnimationFrame(render)}
 const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)schedule();else reset()},{threshold:0});observer.observe(area);
 document.addEventListener('scroll',()=>{if(visible)schedule()},{passive:true});addEventListener('resize',()=>{if(visible)schedule()},{passive:true});
 function reset(){dragging=false;burger.classList.add('returning');['--burger-rx','--burger-ry','--burger-dx','--burger-dy'].forEach(p=>area.style.setProperty(p,'0'+(p.includes('rx')||p.includes('ry')?'deg':'px')));lastPoint=null;clearTimeout(returnTimer);returnTimer=setTimeout(()=>burger.classList.remove('returning'),900)}
 function pop(){if(reduced.matches)return;burger.classList.remove('popped');requestAnimationFrame(()=>burger.classList.add('popped'));clearTimeout(popTimer);popTimer=setTimeout(()=>burger.classList.remove('popped'),700)}
 area.addEventListener('pointermove',e=>{if(reduced.matches||e.pointerType==='touch')return;const r=area.getBoundingClientRect();lastPoint={x:clamp((e.clientX-r.left-r.width/2)/(r.width/2),-1,1),y:clamp((e.clientY-r.top-r.height/2)/(r.height/2),-1,1)};if(dragging){const dx=clamp(e.clientX-originX,-180,180),dy=clamp(e.clientY-originY,-100,100);moved=moved||Math.abs(dx)+Math.abs(dy)>6;area.style.setProperty('--burger-dx',dx+'px');area.style.setProperty('--burger-dy',dy+'px')}schedule()});
 area.addEventListener('pointerleave',()=>{if(!dragging)reset()});
 burger.addEventListener('pointerdown',e=>{moved=false;if(reduced.matches||e.pointerType==='touch')return;dragging=true;originX=e.clientX;originY=e.clientY;burger.classList.remove('returning');burger.setPointerCapture(e.pointerId)});
 burger.addEventListener('pointerup',()=>{if(dragging)reset()});burger.addEventListener('pointercancel',reset);burger.addEventListener('lostpointercapture',()=>{if(dragging)reset()});
 burger.addEventListener('click',()=>{if(!moved)pop();moved=false});
 burger.addEventListener('keydown',e=>{if(reduced.matches)return;if(e.key==='Escape'){reset()}else if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();area.style.setProperty('--burger-ry',e.key==='ArrowLeft'?'-20deg':'20deg');area.style.setProperty('--burger-dx',e.key==='ArrowLeft'?'-35px':'35px');clearTimeout(returnTimer);returnTimer=setTimeout(reset,300)}});
 reduced.addEventListener('change',()=>{reset();if(!reduced.matches)schedule()});
})();
