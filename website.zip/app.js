/* Small, independent interaction modules. No artificial loading delay. */
(()=>{
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const langButton=document.querySelector('#language');
 let lang='zh';try{const saved=localStorage.getItem('portfolio-language');if(saved==='en'||saved==='zh')lang=saved}catch{}
 const applyLanguage=()=>{
  document.documentElement.lang=lang==='zh'?'zh-CN':'en';
  document.querySelectorAll('[data-zh][data-en]').forEach(el=>el.textContent=el.dataset[lang]);
  document.querySelectorAll('.resume-download').forEach(el=>el.href='/assets/resume/chen-luyang-2026.pdf');
  langButton.textContent=lang==='zh'?'中 / EN':'EN / 中';
  langButton.setAttribute('aria-label',lang==='zh'?'Switch to English':'切换到中文');
  if(lang==='en')document.title=({ '/':'Design with Purpose','/work/':'Selected Work','/about/':'About','/resume/':'Resume','/work/mushroom-rent/':'Mushroom Rent','/work/visual-design/':'Dedao Campaign','/work/portfolio/':'Portfolio Experience' }[location.pathname.replace(/^\/lens(?=\/)/,'')]||'Design with Purpose')+' · Product & Visual Designer';
 };
 const originalTitle=document.title;
 langButton.addEventListener('click',()=>{lang=lang==='zh'?'en':'zh';try{localStorage.setItem('portfolio-language',lang)}catch{}if(lang==='zh')document.title=originalTitle;applyLanguage()});applyLanguage();
 const progress=document.querySelector('.progress');let scheduled=false;
 const updateProgress=()=>{const max=document.documentElement.scrollHeight-innerHeight;progress.style.transform=`scaleX(${max>0?scrollY/max:0})`;scheduled=false};
 document.addEventListener('scroll',()=>{if(!scheduled){scheduled=true;requestAnimationFrame(updateProgress)}},{passive:true});addEventListener('resize',updateProgress);updateProgress();
 const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}}),{threshold:0,rootMargin:'0px 0px -6% 0px'});
 if(!reduced.matches)document.querySelectorAll('.about-preview h2,.about-preview p,.section-heading,.section-label,.section-body>p,.section-body>h3,.practice h2,.contact h2,.more .wrap h2').forEach(el=>{el.classList.add('reveal');observer.observe(el)});
 const box=document.querySelector('#lightbox'),big=document.querySelector('#lightbox-image'),stage=document.querySelector('.lightbox-stage'),items=[...document.querySelectorAll('[data-lightbox]')];let index=0,opener=null,previousOverflow='';const zoomButton=document.querySelector('#zoom');function resetZoom(){stage.classList.remove('zoomed');zoomButton.setAttribute('aria-pressed','false')}
 function show(i){index=(i+items.length)%items.length;big.src=items[index].dataset.lightbox;big.alt=items[index].querySelector('img')?.alt||'Artwork';document.querySelector('#lightbox-count').textContent=`${index+1} / ${items.length}`;stage.scrollTop=0;stage.scrollLeft=0;resetZoom()}
 let closing=false;function close(){if(closing||!box.open)return;closing=true;const finish=()=>{box.close();document.body.style.overflow=previousOverflow;opener?.focus();closing=false};if(reduced.matches)finish();else box.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(8px)'}],{duration:180,easing:'ease-in',fill:'none'}).finished.then(finish,finish)}
 items.forEach((item,i)=>item.addEventListener('click',()=>{opener=item;show(i);previousOverflow=document.body.style.overflow;box.showModal();document.body.style.overflow='hidden';document.querySelector('#close').focus()}));
 document.querySelector('#close').onclick=close;box.addEventListener('cancel',e=>{e.preventDefault();close()});document.querySelector('#prev').onclick=()=>show(index-1);document.querySelector('#next').onclick=()=>show(index+1);zoomButton.setAttribute('aria-pressed','false');zoomButton.onclick=()=>{const zoomed=stage.classList.toggle('zoomed');zoomButton.setAttribute('aria-pressed',String(zoomed))};box.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();show(index+1)}if(e.key==='ArrowLeft'){e.preventDefault();show(index-1)}});
 let touchX=0,touchY=0;stage.addEventListener('touchstart',e=>{touchX=e.changedTouches[0].clientX;touchY=e.changedTouches[0].clientY},{passive:true});stage.addEventListener('touchend',e=>{let dx=e.changedTouches[0].clientX-touchX,dy=e.changedTouches[0].clientY-touchY;if(!stage.classList.contains('zoomed')&&Math.abs(dx)>80&&Math.abs(dx)>Math.abs(dy)*1.5)show(index+(dx<0?1:-1))},{passive:true});

})();
